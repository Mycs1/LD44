﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public enum State{
	First,
	Move,
	Second,
	Dead

}
public class Boss : Unit {

	bool isActive=false;

	public State state;
	public Transform[] targets;
	public Transform[] targets2;
	public float rotspeed;
	private Transform currentTarget;
	private int cHp;
	bool isGod=false;
	private int count=0;
	private int curdir = 1;
	public int currId=0;
	void Start () {
		cHp = hp / 2;
		if(targets.Length>0)
		currentTarget = targets [0];
	}

	
	// Update is called once per frame
	void Update () {
		base.Update ();
		switch (state) {
		case State.First:
			Move ();
			Rot ();
			Fire ();
			break;
		case State.Move:
			MoveBack ();
			break;
		case State.Second:
			Move2 ();
			Rot ();
			Fire ();
			break;
		case State.Dead:
			return;
		}
	}
	int ChangeDir(){
		return curdir == 1 ? -1 : 1;
	}

	void Move2(){
		transform.position = Vector3.Lerp (transform.position, targets2[currId].position, Time.deltaTime * speed);
		if (Vector3.Distance (transform.position, targets2[currId].position) < 0.5f) {
			count += 1;
			if (count >= targets2.Length) {
				count -= targets2.Length;
				curdir=ChangeDir ();
			}
			currId += curdir;
			currId = currId >= targets2.Length ? currId - targets2.Length : currId;
			currId = currId < 0 ? currId + targets2.Length : currId;
		}

	}
	protected override void TakeDamage ()
	{if (isGod)
			return;
		hp--;
		if (hp <= cHp) {
			if (state == State.First) {
				isGod = true;
				state = State.Move;
			}
			if (hp <= 0) {
				state = State.Dead;
				Destroy (gameObject);
			}
		}
	}
	public void StartBoss(){
		
		isActive = true;

	}
	void RandomPosition(){
		currentTarget= targets[Random.Range(0,targets.Length)];
	}
	void Move(){
		transform.position = Vector3.Lerp (transform.position, currentTarget.position, Time.deltaTime * speed);
		if (Vector3.Distance (transform.position, currentTarget.position) < 0.5f) {
			RandomPosition ();
		}
	}
	void Rot(){
		transform.Rotate (Vector3.up * rotspeed * Time.deltaTime);
	}
	void MoveBack(){
		transform.position = Vector3.Lerp (transform.position, targets2[0].position, Time.deltaTime * speed);
		if (Vector3.Distance (transform.position, targets2[0].position) < 0.5f) {
			GameManager.Instance.State2 ();
			state = State.Second;
			coolDown += 0.1f;
			speed *= 2;
			isGod = false;
		}

	}
}
