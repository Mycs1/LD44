﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public enum AF{
	P,
	E
}
public class Bullet : MonoBehaviour {

	public AF af;
	public float speed;
	void Start () {
		GetComponent<Rigidbody> ().velocity = transform.forward*speed;
		Destroy (gameObject, 7f);
	}
	void OnTriggerEnter(Collider coll){
		if (coll.CompareTag ("Wall"))
			Destroy (gameObject);
	}
}
