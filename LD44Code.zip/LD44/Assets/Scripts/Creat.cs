﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Creat : MonoBehaviour {

	public float x;
	public float z;
	public GameObject toInst;
	public float startTime=2f;
	public float repeatTime=5f;
	void Start () {
		InvokeRepeating ("CreatEnemy", startTime, repeatTime);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void CreatEnemy(){
		Instantiate (toInst, GetRandomPosition (), Quaternion.identity);
	}
	Vector3 GetRandomPosition(){
		float t1 = Random.Range (transform.position.x - x, transform.position.x + x);
		float t2 = Random.Range (transform.position.z - z, transform.position.z + z);
		return new Vector3 (t1, transform.position.y, t2);
	}
}
