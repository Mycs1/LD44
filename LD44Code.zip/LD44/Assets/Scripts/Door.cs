﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Door : MonoBehaviour {

	public GameObject CPoint;
	public int level;
	public int hpCost;
	public Text info;
	void Awake(){
		if(CPoint!=null)
			CPoint.SetActive (false);

	}
	void Start () {
		
		info.text = "lv: " + level+"\nHp:"+hpCost;
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnCollisionEnter(Collision coll){
		if (coll.collider.CompareTag ("Player")) {
			Player p = coll.collider.GetComponent<Player> ();
			if ((p.level >= level) && (p.hp > hpCost)) {
				p.PayCost(hpCost);
				p.AddLevel ();
				if(CPoint!=null)
				CPoint.SetActive (true);
				Destroy (gameObject);
			}
		}
	}
}
