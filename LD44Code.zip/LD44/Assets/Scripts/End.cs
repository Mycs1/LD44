﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class End : MonoBehaviour {

	public GameObject[] to;
	void Start () {
		for (int i = 0; i < to.Length; i++) {
			to [i].SetActive (false);

		}
	}
	
	void OnTriggerEnter(Collider coll){
		if (coll.CompareTag ("Player")) {
			for (int i = 0; i < to.Length; i++) {
				to [i].SetActive (true);

			}
			Destroy (gameObject);
		}

	}
}
