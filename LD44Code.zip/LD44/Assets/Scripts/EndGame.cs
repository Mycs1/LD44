﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndGame : MonoBehaviour {

	void OnTriggerEnter(Collider coll){
		if (coll.CompareTag ("Player")) {
			Application.Quit ();
		}

	}
}
