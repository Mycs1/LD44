﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : Unit {

	public float searchDis=20f;
	public float stopDis=5f;
	public float rotspeed;
	private Transform target;
	void Start () {
		target = GameObject.FindWithTag ("Player").transform;
	}
	
	// Update is called once per frame
	void Update () {
		if (target == null)
			return;
		base.Update ();
		if (Vector3.Distance (transform.position, target.position) < searchDis) {
			Rot ();
			Fire ();
			if (Vector3.Distance (transform.position, target.position) > stopDis) {
				Move ();
			}

		}
	}

	 void Move(){
		transform.Translate (Vector3.forward * speed * Time.deltaTime);
	}
	 void Rot(){
		Quaternion wantedRotation = Quaternion.LookRotation (target.position - transform.position);
		transform.rotation = Quaternion.Slerp (transform.rotation, wantedRotation, Time.deltaTime*rotspeed);
	}

	protected override void TakeDamage ()
	{
		hp--;
		if (hp <= 0) {
			if(target!=null)
			target.GetComponent<Player> ().AddHp (level);
			Destroy (gameObject);
		}
	}

}
