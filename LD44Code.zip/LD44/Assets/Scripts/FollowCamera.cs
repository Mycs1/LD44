﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowCamera : MonoBehaviour {

	public Transform targrt;
	public float speed;
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if(targrt!=null)
		transform.position = Vector3.Lerp (transform.position, new Vector3(targrt.position.x,transform.position.y,targrt.position.z), Time.deltaTime * speed);
	}
}
