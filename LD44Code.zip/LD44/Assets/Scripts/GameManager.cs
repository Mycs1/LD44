﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {

	public static GameManager Instance;
	public GameObject[] HpBar;
	public GameObject[] boss2;
	private Image[] HpBarImages;
	public GameObject gamOver;
	public GameObject gamWin;
	void Start () {
		HpBarImages=new Image[3]; 
		Instance = this;
		for (int i = 0; i < boss2.Length; i++) {
			boss2 [i].SetActive (false);
			HpBarImages[i] = HpBar [i].GetComponent<Image> ();
			HpBar [i].SetActive (false);
		}if(gamOver!=null)
		gamOver.SetActive (false);
		if(gamWin!=null)
		gamWin.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetKeyDown (KeyCode.Escape)) {
			Quit ();
		}
		ShowHp ();
		if (CheckBoss ()) {
			gamWin.SetActive (true);
		}
	}
	public void GameOver(){
		gamOver.SetActive (true);

	}
	void ShowHp(){
		if (boss2 [0] != null) {
			HpBarImages[0].fillAmount=boss2[0].GetComponent<Boss> ().hp /50f;
		}
		for (int i = 1; i < boss2.Length; i++) {
			if (boss2 [i] != null) {
				HpBarImages [i].fillAmount = boss2 [i].GetComponent<Boss> ().hp / 25f;
			}
		}

	}
	bool CheckBoss(){
		for (int i = 0; i < boss2.Length; i++) {
			if (boss2 [i] != null)
				return false;
		}
		return true;

	}


	public void State1(){
		boss2 [0].SetActive (true);
		HpBar [0].SetActive (true);
	}

	public void State2(){
		for (int i = 1; i < boss2.Length; i++) {
			boss2 [i].SetActive (true);
			HpBar [i].SetActive (true);
		}
	}
	public void Restart(int id){

		SceneManager.LoadScene(id);
	}
	public void Quit(){
		Application.Quit ();
	}
}
