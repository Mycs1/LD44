﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Player : Unit {

	private RaycastHit hit;
	public Text playerHp;
	public bool isGod=false;
	void Update () {
		if (playerHp != null) {
			playerHp.text = "lv: " + level+"\nHp: " + hp;
		}
		base.Update ();
		Move ();
		Rot ();
		if (Input.GetMouseButton (0)) {
			Fire ();
		}
	}
	 void Move(){
		float h = Input.GetAxis ("Horizontal");
		float v = Input.GetAxis ("Vertical");
		if (h != 0 || v != 0) {
			transform.Translate (new Vector3 (h, 0, v)*speed*Time.deltaTime, Space.World);
		}
	}
	 void Rot(){
		if(Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition),out hit))
			transform.LookAt (new Vector3(hit.point.x,transform.position.y,hit.point.z));
	}

	public void AddHp(int _hp){
		hp += _hp;
	}
	public void AddLevel(){
		level++;
	}
	public void PayCost(int cost){
		hp -= cost;
	}
	protected override void TakeDamage ()
	{if (isGod)
		return;
		hp--;
		if (hp <= 0) {
			if(GameManager.Instance!=null)
			GameManager.Instance.GameOver ();
			Destroy (gameObject);
		}
	}
}
