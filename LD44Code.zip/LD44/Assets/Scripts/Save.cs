﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Save : MonoBehaviour {

	void OnApplicionQuit(){

		PlayerPrefs.SetInt ("Hp",10);

	}
}
