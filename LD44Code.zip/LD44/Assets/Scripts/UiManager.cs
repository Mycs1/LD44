﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UiManager : MonoBehaviour {

	public GameObject gamOver;
	Transform t;
	void Start () {
		t = GameObject.FindWithTag ("Player").transform;
		gamOver.SetActive (false);
	}
	
	// Update is called once per frame
	void Update () {
		if (t == null)
			GameOver ();
		if (Input.GetKeyDown (KeyCode.Escape)) {
			Application.Quit ();
		}
	}

	public void GameOver(){
		gamOver.SetActive (true);
	}
}
