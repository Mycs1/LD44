﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unit : MonoBehaviour {
	public int hp;
	public int level;
	public float speed=3;
	public float coolDown;
	public Transform[] firePosition;
	public GameObject bulletPrefab;
	public AF af;
	public int[] bulletControl;
	private float timer;

	void Start () {
		timer = coolDown;
	}

	// Update is called once per frame
	public void Update () {
		timer += Time.deltaTime;
	}
	protected void Fire(){
		//Debug.Log ("fire");
		if (timer > coolDown) {
			for (int i = 0; i < bulletControl [level - 1]; i++)
				CreatBullet (firePosition [i].position, firePosition [i].rotation);
			timer = 0f;
		}
	}
	void CreatBullet(Vector3 position,Quaternion rotation){
		Instantiate (bulletPrefab, position, rotation);
	}
	void OnTriggerEnter(Collider coll){
		if (coll.CompareTag ("Bullet")) {
			if (!(coll.GetComponent<Bullet> ().af == this.af)) {
				TakeDamage ();
				Destroy (coll.gameObject);
			}
		}
	}
	protected virtual void TakeDamage(){
		hp--;
		if (hp <= 0) {
			Destroy (gameObject);
		}
	}
}
